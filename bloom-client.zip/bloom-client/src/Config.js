const Config = {
  client: "http://localhost:3000",
  server: "http://localhost:4000"
  // server: "https://evening-bayou-56962.herokuapp.com"
};

export default Config;
