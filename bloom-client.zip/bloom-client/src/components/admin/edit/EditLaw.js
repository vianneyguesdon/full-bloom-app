import React from "react";

class EditLaw extends React.Component {
  render() {
    return <div>EditLaw</div>;
  }
}

export default EditLaw;
