import React from "react";

class EditLawCategory extends React.Component {
  render() {
    return <div>EditLawCategory</div>;
  }
}

export default EditLawCategory;
