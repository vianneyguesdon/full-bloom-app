import React from "react";

class EditVote extends React.Component {
  render() {
    return <div>EditVote</div>;
  }
}

export default EditVote;
