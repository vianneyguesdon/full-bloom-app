import React from "react";

class EditGroup extends React.Component {
  render() {
    return <div>EditGroup</div>;
  }
}

export default EditGroup;
